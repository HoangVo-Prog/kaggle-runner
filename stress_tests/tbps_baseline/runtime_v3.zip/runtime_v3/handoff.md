# V3 handoff — preparation only

Session: `v3-prep-20261125-80dd8253cff54e7899f74746f31f314c`  
Objective: `tbps-baseline-3gpu` (one verified existing match found)  
Runner: `20d68d73d079d5481d855792f97595fea6f47b2a`, branch `codex/agent-readiness-hardening`; worktree had pre-existing local changes.  
TBPS: `fa5e0192e937603edb3e02001bb3ba09aec98414`, branch `main`, clean.  
Interpreter: `D:\Miniconda\python.exe`; no `kgr` command was found. `python -m kaggle_runner --help` worked and imported this checkout.

## Three-run preparation

`run-matrix.json` records three distinct dataset rows, one attempt each. The derived notebook copies keep IRRA, augmentation, batch size 64, ITC, and 60 epochs. They set the dataset for each run, pin the observed TBPS checkout, and propose a two-process `torchrun` launch to use T4x2. Kaggle runtime support for that launcher is unverified.

Observed seed behavior is `1 + distributed rank`; actual per-process seeds depend on the launch and world size. `val_dataset` defaults to `test`. The evaluator computes text-to-image Rank-1/5/10, mAP, and mINP; it returns text-to-image R1, which selects the best checkpoint. Dataset sample counts and GPU-hour estimates are unknown. Source code saves a time-stamped `best.pth`, training log, and config, but no KGR `result.json` writer was found.

The original notebook was not modified. Derived, non-executable copies are under `drafts/`; `drafts/adaptation.diff` records the changes. The copies still clone code and install requirements at runtime, so they need network access and the model dependency. No Kaggle model reference was invented. Structural package inspection succeeded for the original and all three drafts. It did not verify reproducibility, runtime readiness, resource access, experiment validity, dependencies, or execution authorization; reports flag external source, runtime install, dataset path, network resource, and missing result writer.

## Blockers

1. Two read-only `setup discover` calls returned `ok=true`, `status=verified`, one matching objective, and a stable ledger identity. The audit wrapper then recorded `invalid_output` and refused binding. Its secret redactor transforms the nested `authorization` object into unquoted `[REDACTED]`, corrupting JSON before `bind_verified`. Retrying against the same confirmed candidate reproduced the failure. No preflight, setup checkpoint read, `work show`, objective mutation, or remote reconciliation was run. The discovery command saved a secret-free bootstrap pointer.
2. `case.json` has no approved profile, GPU-hour budget, per-run estimate, or internet policy; it sets live authorization false. None were inferred.
3. Complete ExperimentSpecs cannot be validated until profile, budget, internet policy, result integration, expected artifacts, and sample-count evidence are supplied. The drafts are not submit-ready; no spec validation is claimed.

## Next safe action

Review the V3 audit redaction/binding defect. Then perform verified state discovery, offline preflight, and inspect the existing setup checkpoint and objective revision/next action using the identity-bound audit path. If that path cannot be restored safely, provide an operator-reviewed testbed workflow; state was not accessed outside the guard. Next resolve the authorized profile, exact total and per-run GPU-hour caps, internet policy, package/model access, and result writer/expected artifacts. Validate three complete specs, then seek separate explicit authorization for the exact plan. This handoff does not authorize a live action.

## Friction and audit

See `audit-summary.md`, `checklist.csv`, `events.jsonl`, and `commands/`. Recorded incidents include Git safe-directory rejection (worked around per command without changing global config), two audit-binding failures, a derived-draft authoring `NameError` and corrected retry, two premature package inspections of missing draft paths, and an inline artifact-writer quoting/redaction failure followed by a direct-patch workaround. No tests, Kaggle API operation, credential change, submission, GPU allocation, training, global configuration change, or Kaggle Runner source edit occurred. The operator must independently verify cross-identity access to these local artifacts.
